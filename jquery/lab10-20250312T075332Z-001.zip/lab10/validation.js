/* function validate()will validate form data */
function validate() {
  var sid = document.getElementById("sid").value;
  var pwd1 = document.getElementById("pwd1").value;
  var pwd2 = document.getElementById("pwd2").value;
  var uname = document.getElementById("uname").value;
  var genm = document.getElementById("genm").checked;
  var genf = document.getElementById("genf").checked;
  var pattern = /^[a-zA-Z\s]+$/; // Regular expression for letters and spaces
  var errMsg = "";
  var result = true;

  if (sid == "") {
    errMsg += "<li>User ID cannot be empty.</li>";
  }
  if (pwd1 == "") {
    errMsg += "<li>Password cannot be empty.</li>";
  }
  if (pwd2 == "") {
    errMsg += "<li>Retype password cannot be empty.</li>";
  }
  if (uname == "") {
    errMsg += "<li>User name cannot be empty.</li>";
  }
  if (!genm && !genf) {
    errMsg += "<li>A gender must be selected.</li>";
  }
  if (sid.indexOf('@') == 0) {
    errMsg += "<li>User ID cannot start with an @ symbol.</li>";
  }
  if (sid.indexOf('@') < 0) {
    errMsg += "<li>User ID must contain an @ symbol.</li>";
  }
  if (pwd1 != pwd2) {
    errMsg += "<li>Passwords do not match.</li>";
  }
  if (!uname.match(pattern)) {
    errMsg += "<li>User name contains symbols.</li>";
  }

  if (errMsg != "") {
    errMsg =
      "<div id='scrnOverlay'></div>" +
      "<section id='errWin' class='window'><ul>" +
      errMsg +
      "</ul><a href='#' id='errBtn' class='button'>Close</a></section>";
    var numOfItems = errMsg.match(/<li>/g).length + 6;
    $("body").after(errMsg);
    $("#scrnOverlay").css("visibility", "visible");
    $("#errWin").css("height", numOfItems.toString() + "em");
    $("#errWin").css("margin-top", (numOfItems / -2).toString() + "em");
    $("#errWin").show();
    $("#errBtn").click(function () {
      $("#scrnOverlay").remove();
      $("#errWin").remove();
    });
    result = false;
  }

  return result;
}

/* link HTML elements to corresponding event function */
function init () {
	/* assign the <form> element to variable regForm */

	/* link function validate() to the onsubmit event of the form */
	$("#regform").submit(validate);
	}

/* execute function init() once the window is loaded*/
	$(document).ready(init);
function toggle (){
	$(this).parent().next().slideToggle(); /* see explanation (7) below */
	if ($(this).html() == "[-]"){ /* Update the symbol on the "button" */
	$(this).html("[+]");
	} else { /* [-] <-> [+] */
	$(this).html("[-]");
	}
	}
	/* link HTML elements to corresponding event function */
	function init() {
	$(".collapse").click(toggle); //link function toogle() to appropriate events
	$("#regform").submit(validate);/*link function validate() to the submit event of the
	form */
	}
	
function validate() {
  var sid = document.getElementById("sid").value;
  var pwd1 = document.getElementById("pwd1").value;
  var pwd2 = document.getElementById("pwd2").value;
  var uname = document.getElementById("uname").value;
  var genm = document.getElementById("genm").checked;
  var genf = document.getElementById("genf").checked;
  var pattern = /^[a-zA-Z\s]+$/; // Regular expression for letters and spaces
  var errMsg = "";
  var result = true;

  if (sid == "") {
    errMsg += "<li>User ID cannot be empty.</li>";
  }
  if (pwd1 == "") {
    errMsg += "<li>Password cannot be empty.</li>";
  }
  if (pwd2 == "") {
    errMsg += "<li>Retype password cannot be empty.</li>";
  }
  if (uname == "") {
    errMsg += "<li>User name cannot be empty.</li>";
  }
  if (!genm && !genf) {
    errMsg += "<li>A gender must be selected.</li>";
  }
  if (sid.indexOf('@') == 0) {
    errMsg += "<li>User ID cannot start with an @ symbol.</li>";
  }
  if (sid.indexOf('@') < 0) {
    errMsg += "<li>User ID must contain an @ symbol.</li>";
  }
  if (pwd1 != pwd2) {
    errMsg += "<li>Passwords do not match.</li>";
  }
  if (!uname.match(pattern)) {
    errMsg += "<li>User name contains symbols.</li>";
  }

  if (errMsg != "") {
    errMsg =
      "<div id='scrnOverlay'></div>" +
      "<section id='errWin' class='window'><ul>" +
      errMsg +
      "</ul><a href='#' id='errBtn' class='button'>Close</a></section>";
    var numOfItems = errMsg.match(/<li>/g).length + 6;
    $("body").after(errMsg);
    $("#scrnOverlay").css("visibility", "visible");
    $("#errWin").css("height", numOfItems.toString() + "em");
    $("#errWin").css("margin-top", (numOfItems / -2).toString() + "em");
    $("#errWin").show();
    $("#errBtn").click(function () {
      $("#scrnOverlay").remove();
      $("#errWin").remove();
    });
    result = false;
  }

  return result;
}