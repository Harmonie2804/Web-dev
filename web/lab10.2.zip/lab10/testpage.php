<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="description" content="Test Page template for SSI" />
  <title>Test Page template for SSI</title>
  <!-- (1) Link to desktop CSS file -->
  <link href="regform2_desktop.css" rel="stylesheet" type="text/css" media="screen and (min-device-width:481px)" />
  <!-- (2) Link to modal CSS file for Task 3 -->
  <link href="modal.css" rel="stylesheet" type="text/css" />
</head>
<body>
  <div id="container">
    <!--#include file="header.ssi" -->
    <!--#include file="nav.ssi" -->
    
    <!-- Start Main Content -->
    <main id="content">
      <h1>Main page Content</h1>
      <p>This is the main part of the webpage.</p>
    </main>
    <!-- End Main Content -->

    <!--#include file="footer.ssi" -->
  </div>
</body>
</html>
